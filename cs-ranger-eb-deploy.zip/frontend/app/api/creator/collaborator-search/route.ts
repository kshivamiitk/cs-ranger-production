// Auto-generated v21 route bridge.
// Backend team owns the implementation; this file only mounts it for Next.js local/full-stack execution.
export * from '../../../../../backend/Data, Growth & Experience/routes/creator/collaborator-search/route.ts';



