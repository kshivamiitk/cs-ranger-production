// Auto-generated v21 route bridge.
// Backend team owns the implementation; this file only mounts it for Next.js local/full-stack execution.
export * from '../../../../../../../backend/Learning Engine/routes/nodes/[nodeId]/discussions/comments/route.ts';



